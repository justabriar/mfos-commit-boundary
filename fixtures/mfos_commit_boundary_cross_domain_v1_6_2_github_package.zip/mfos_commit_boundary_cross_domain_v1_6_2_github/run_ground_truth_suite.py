#!/usr/bin/env python3
import json
import sys
from pathlib import Path

try:
    import jsonschema
except ImportError:
    print("Missing dependency: jsonschema. Install with: pip install -r requirements.txt")
    sys.exit(2)

ROOT = Path(__file__).resolve().parent
SUITE_PATH = ROOT / "mfos_ground_truth_suite_v1_6_2.json"


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def get_path(obj, path):
    cur = obj
    for part in path.split("."):
        cur = cur[part]
    return cur


def maybe_check(case, packet, actual_path, expected_path, failures):
    cur = case
    for part in expected_path.split('.'):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return
    actual = get_path(packet, actual_path)
    if actual != cur:
        failures.append(f"{actual_path}: expected {cur!r}, got {actual!r}")


def main():
    suite = load_json(SUITE_PATH)
    schema = load_json(ROOT / suite["schemaFile"])

    total = len(suite["cases"])
    passed = 0
    failures = []

    checks = [
        ("pressureProfile.level", "expected.pressureProfile.level"),
        ("pressureProfile.score", "expected.pressureProfile.score"),
        ("actionIntent.present", "expected.actionIntent.present"),
        ("actionIntent.types", "expected.actionIntent.types"),
        ("consequenceProfile.level", "expected.consequenceProfile.level"),
        ("consequenceProfile.score", "expected.consequenceProfile.score"),
        ("processingProfile.evaluationMode", "expected.processingProfile.evaluationMode"),
        ("processingProfile.commitBoundaryEligible", "expected.processingProfile.commitBoundaryEligible"),
        ("processingProfile.executionOwnerBinding.replayBinding.verified", "expected.processingProfile.replayBindingVerified"),
        ("boundaryMetadata.boundaryPresence", "expected.boundaryMetadata.boundaryPresence"),
        ("boundaryMetadata.commitTriggerBasis", "expected.boundaryMetadata.commitTriggerBasis"),
        ("boundaryMetadata.boundaryState.state", "expected.boundaryMetadata.boundaryState"),
        ("mfosGate.status", "expected.mfosGate.status"),
        ("mfosGate.authoritySource", "expected.mfosGate.authoritySource"),
        ("mfosGate.decisionRequired", "expected.mfosGate.decisionRequired"),
        ("mfosGate.kernelAction", "expected.mfosGate.kernelAction"),
        ("mfosGate.executionAccountability.state", "expected.mfosGate.executionAccountabilityState"),
        ("mfosGate.overrideRecord.overrideRequested", "expected.mfosGate.overrideRequested"),
        ("decisionAuthority.actorBinding.separationVerified", "expected.decisionAuthority.separationVerified"),
        ("auditRecord.decisionBinding.bindingStatus", "expected.auditRecord.decisionBindingStatus"),
        ("auditRecord.decisionBinding.hashesAligned", "expected.auditRecord.hashesAligned"),
        ("auditRecord.decisionBinding.bindingFresh", "expected.auditRecord.bindingFresh"),
        ("transformationIntegrity.technicalCorrectness", "expected.transformationIntegrity.technicalCorrectness"),
        ("executionReadiness.applicable", "expected.executionReadiness.applicable"),
        ("executionReadiness.safeToCommit", "expected.executionReadiness.safeToCommit"),
        ("executionReadiness.failureMode", "expected.executionReadiness.failureMode"),
        ("executionReadiness.notApplicableReason", "expected.executionReadiness.notApplicableReason"),
        ("compatibility.refinedSummary.executionReadiness", "expected.compatibility.refinedSummaryExecutionReadiness"),
    ]

    for case in suite["cases"]:
        case_id = case["id"]
        packet = case["packet"]
        try:
            jsonschema.validate(packet, schema)
        except jsonschema.ValidationError as e:
            failures.append((case_id, f"schema validation failed: {e.message}"))
            continue

        case_failures = []
        for actual_path, expected_path in checks:
            maybe_check(case, packet, actual_path, expected_path, case_failures)

        expected_reason_codes = case["expected"].get("mustIncludeReasonCodes", [])
        actual_reason_codes = packet["mfosGate"]["executionAccountability"]["openReasonCodes"]
        for code in expected_reason_codes:
            if code not in actual_reason_codes:
                case_failures.append(f"missing reason code: {code}")

        if case_failures:
            failures.append((case_id, "; ".join(case_failures)))
        else:
            passed += 1
            print(f"PASS  {case_id}")

    print()
    print(f"Summary: {passed}/{total} cases passed")
    if failures:
        print()
        print("Failures:")
        for case_id, reason in failures:
            print(f"- {case_id}: {reason}")
        sys.exit(1)


if __name__ == "__main__":
    main()
