MFOS Commit Boundary Cross-Domain Package v1.6.2

Purpose
This package tightens the gate.
MFOS still governs the last mile where recommendation becomes action.
The v1.6.2 patch makes that gate more mechanical by binding conditions, actors, review state, override trace, and boundary lifecycle into the packet itself.

Why this version
v1.6.1 proved that MFOS can stay observational when no real commit boundary exists.
The next weakness was softer than that.
Important gate facts still lived in loose strings or were only implied by surrounding fields.
That left too much room for packets that looked governed without fully proving who reviewed what, whether the reviewed artifact still matched the commit candidate, whether role separation was verified, and whether open unknowns still blocked release.

What changed
- schemaVersion bumped to 1.6.2
- boundaryMetadata.criticalUnknowns is now typed instead of string-only
- added boundaryMetadata.boundaryState for explicit lifecycle state
- added decisionAuthority.actorBinding for named requester, reviewer, approver, executor, and separation verification
- added mfosGate.conditionSet for typed condition evaluation
- added mfosGate.overrideRecord for explicit override trace
- added processingProfile.executionOwnerBinding.replayBinding
- added auditRecord.decisionBinding for reviewed-hash, commit-hash, policy-hash, freshness, and idempotency binding
- extended reason-code catalog with stale-binding, hash-mismatch, unsatisfied-condition, open-unknown, role-separation, and override-escalation lanes
- patched cross-field rules so ALLOW cannot coexist with open ALLOW-blocking unknowns, stale review binding, or unsatisfied ALLOW conditions

Design read
MFOS does not get stronger by adding more rhetoric.
It gets stronger by making the packet prove more.
v1.6.2 moves enforcement away from descriptive language and toward typed mechanical checks:
1. who is involved
2. what exact thing was reviewed
3. whether the reviewed thing still matches the commit candidate
4. whether open unknowns still block ALLOW
5. whether override activity is explicit or absent

Included cases
- clean_general_allow_001
- false_positive_resistance_allow_001
- finance_review_001
- medical_review_001
- architecture_slow_001
- aviation_block_001
- warehouse_block_001
- sandbox_no_boundary_001

How to run
1. Create a Python environment if you want isolation.
2. Install the runner dependency:
   pip install -r requirements.txt
3. Run:
   python run_ground_truth_suite.py

Expected result
Summary: 8/8 cases passed

Packaging note
This package does not bundle third-party code.
The runner depends on jsonschema as an external install declared in requirements.txt.
